# Liquidity Sweep PRO v2.0

A fresh Android dashboard UI for the MT5 Liquidity Sweep v1.08 workflow.

## What is included
- Large mobile-first dashboard cards
- Portfolio / Balance / Equity / Today P&L
- Equity curve graphic
- Signal card with BUY / WAIT state
- Entry / SL / TP / Lot / R:R / Recovery
- Daily target and loss progress
- Win/Loss / Win Rate performance
- Recent activity log
- MT5 Bridge / Telegram status panel
- Trades, Settings and Alerts screens
- Settings matching Liquidity Sweep v1.08 defaults
- Pause / Resume, Close All, Refresh UI controls
- GitHub Actions workflow that builds a debug APK

## Important
The displayed market values are UI/demo values until a real MT5 bridge/API is connected. The dashboard does not directly connect to MT5 merely by installing the APK.
