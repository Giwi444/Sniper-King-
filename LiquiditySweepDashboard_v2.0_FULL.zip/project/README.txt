LIQUIDITY SWEEP DASHBOARD v2.0

Full mobile portrait dashboard UI for Liquidity Sweep EA v1.08.

Included:
- Premium dark trading-terminal UI
- Large readable typography
- Account Balance / Equity / P&L cards
- Floating P/L, Open Trades, Recovery
- Equity/P&L graphic chart with Sweep / BUY / SELL markers
- Active signal card with Entry / SL / TP
- Risk / Recovery panel
- Daily Target / Loss panel
- Quick control buttons
- EA Settings screen for v1.08 parameters
- Telegram status / command panel
- System Logs screen
- Alerts screen
- Bottom Home / Settings / Logs / Alerts navigation
- Portrait-locked mobile layout

Important: This build is a polished local dashboard UI. Live MT5 data still requires a data bridge from MT5 to Android; Telegram controls are represented in the UI but are not a direct MT5 socket.

Build with:
gradle assembleDebug --no-daemon
