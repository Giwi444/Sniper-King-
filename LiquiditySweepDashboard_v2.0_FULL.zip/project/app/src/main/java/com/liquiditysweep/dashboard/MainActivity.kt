package com.liquiditysweep.dashboard

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.Toast
import kotlin.math.min

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setStatusBarColor(Color.rgb(5,9,14))
        window.setNavigationBarColor(Color.rgb(5,9,14))
        setContentView(DashboardView())
    }

    inner class DashboardView : View(this@MainActivity) {
        private val bg = Color.rgb(5,9,14)
        private val card = Color.rgb(12,19,28)
        private val card2 = Color.rgb(16,25,36)
        private val green = Color.rgb(40,230,145)
        private val blue = Color.rgb(73,158,255)
        private val red = Color.rgb(255,83,103)
        private val white = Color.rgb(240,247,250)
        private val muted = Color.rgb(139,155,168)
        private val grid = Color.rgb(29,43,56)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var tab = 0
        private var paused = false
        private var scroll = 0f
        private var downY = 0f

        init { isFocusable = true }

        private fun rr(c: Canvas, l: Float,t:Float,r:Float,b:Float,rad:Float,color:Int) {
            p.color=color; p.style=Paint.Style.FILL; c.drawRoundRect(l,t,r,b,rad,rad,p)
        }
        private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean=false) {
            p.color=color; p.textSize=size; p.typeface=if(bold) Typeface.create("sans-serif",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL); p.style=Paint.Style.FILL
            c.drawText(s,x,y,p)
        }
        private fun line(c:Canvas,x1:Float,y1:Float,x2:Float,y2:Float,color:Int,w:Float=1f){p.color=color;p.strokeWidth=w;p.style=Paint.Style.STROKE;c.drawLine(x1,y1,x2,y2,p)}
        private fun section(c:Canvas,y:Float,title:String,sub:String="") { text(c,title,18,y,12,muted,true); if(sub.isNotEmpty()) text(c,sub,18,y+18,11,muted,false) }

        override fun onDraw(c: Canvas) {
            super.onDraw(c); c.drawColor(bg)
            val w=width.toFloat(); val pad=16f; val cw=w-pad*2
            c.save(); c.translate(0,-scroll)
            header(c,pad,cw)
            when(tab){0->home(c,pad,cw);1->settings(c,pad,cw);2->logs(c,pad,cw);3->alerts(c,pad,cw)}
            c.restore()
            bottom(c,w)
        }
        private fun header(c:Canvas,pad:Float,cw:Float){
            text(c,"LIQUIDITY",pad,32,22,white,true); text(c,"SWEEP",pad,56,22,green,true)
            text(c,"EA CONTROL CENTER",pad,76,10,muted,true)
            rr(c,width-105f,18,width-16f,52f,18f,if(paused)Color.rgb(48,27,32) else Color.rgb(12,55,40))
            p.color=if(paused)red else green; c.drawCircle(width-91f,35f,4f,p)
            text(c,if(paused)"PAUSED" else "RUNNING",width-82f,40f,11f,if(paused)red else green,true)
        }
        private fun home(c:Canvas,pad:Float,cw:Float){
            var y=100f
            rr(c,pad,y,pad+cw,y+128,24f,card)
            text(c,"ACCOUNT VALUE",pad+18,y+28,10,muted,true)
            text(c,"$1,000.00",pad+18,y+65,30,white,true)
            text(c,"Equity  $1,012.84",pad+18,y+88,12,muted)
            text(c,"+$12.84",pad+18,y+113,16,green,true)
            text(c,"+1.28%",pad+cw-68,y+113,12,green,true)
            y+=144
            val gap=10f; val sw=(cw-gap*2)/3f
            stat(c,pad,y,sw,"FLOAT P/L","+$12.84",green); stat(c,pad+sw+gap,y,sw,"OPEN TRADES","1",white); stat(c,pad+(sw+gap)*2,y,sw,"RECOVERY","0 / 2",blue)
            y+=94
            rr(c,pad,y,pad+cw,y+260,24f,card)
            text(c,"EQUITY / P&L",pad+18,y+28,11,muted,true); text(c,"Today +$12.84",pad+cw-105,y+28,10,green,true)
            chart(c,pad+16,y+50,cw-32,175)
            y+=280
            rr(c,pad,y,pad+cw,y+185,24f,card)
            text(c,"ACTIVE SIGNAL",pad+18,y+28,11,muted,true)
            rr(c,pad+cw-82,y+12,pad+cw-18,y+40,14f,Color.rgb(12,55,40)); text(c,"BUY",pad+cw-66,y+31,11,green,true)
            text(c,"BTCUSD",pad+18,y+61,22,white,true); text(c,"Liquidity sweep confirmed",pad+18,y+82,11,muted)
            row(c,pad+18,y+110,"Entry","104,250.00",white); row(c,pad+18,y+132,"SL","103,750.00",red); row(c,pad+18,y+154,"TP","105,250.00",green)
            y+=205
            rr(c,pad,y,pad+cw,y+105,24f,card)
            text(c,"RISK / RECOVERY",pad+18,y+28,11,muted,true)
            progress(c,pad+18,y+48,cw-36,10,0.35f,blue)
            text(c,"Lot 0.01",pad+18,y+80,12,white,true); text(c,"RR 1:2",pad+110,y+80,12,white,true); text(c,"Max lot 0.05",pad+190,y+80,12,white,true)
            y+=125
            text(c,"QUICK CONTROL",pad,y+10,11,muted,true)
            button(c,pad,y+24,(cw-20)/3f,58,"PAUSE",if(paused)blue else green)
            button(c,pad+(cw-20)/3f+10,y+24,(cw-20)/3f,58,"CLOSE ALL",red)
            button(c,pad+2*((cw-20)/3f+10),y+24,(cw-20)/3f,58,"REFRESH",blue)
            y+=104
            rr(c,pad,y,pad+cw,y+155,24f,card)
            text(c,"DAILY LIMITS",pad+18,y+28,11,muted,true)
            row(c,pad+18,y+62,"Target","$50.00",green); row(c,pad+18,y+88,"Loss limit","$50.00",red); row(c,pad+18,y+114,"Current","+$12.84",green)
            progress(c,pad+18,y+130,cw-36,8,0.26f,green)
        }
        private fun stat(c:Canvas,x:Float,y:Float,w:Float,l:String,v:String,col:Int){rr(c,x,y,x+w,y+82,20f,card);text(c,l,x+12,y+22,9,muted,true);text(c,v,x+12,y+55,17,col,true)}
        private fun row(c:Canvas,x:Float,y:Float,l:String,v:String,col:Int){text(c,l,x,y,11,muted); text(c,v,x+width-150,y,11,col,true)}
        private fun progress(c:Canvas,x:Float,y:Float,w:Float,h:Float,f:Float,col:Int){rr(c,x,y,x+w,y+h,h/2,grid);rr(c,x,y,x+w*f,y+h,h/2,col)}
        private fun chart(c:Canvas,x:Float,y:Float,w:Float,h:Float){
            for(i in 0..4) line(c,x,y+i*h/4,x+w,y+i*h/4,grid,1f)
            for(i in 0..6) line(c,x+i*w/6,y,x+i*w/6,y+h,grid,1f)
            val pts=arrayOf(0.00f to .72f,.12f to .66f,.24f to .78f,.36f to .55f,.48f to .61f,.60f to .40f,.72f to .46f,.84f to .25f,1f to .18f)
            p.color=green;p.strokeWidth=4f;p.style=Paint.Style.STROKE
            val path=Path(); pts.forEachIndexed{idx,(xx,yy)->val px=x+xx*w;val py=y+yy*h;if(idx==0)path.moveTo(px,py)else path.lineTo(px,py)};c.drawPath(path,p)
            pts.forEach{(xx,yy)->p.style=Paint.Style.FILL;c.drawCircle(x+xx*w,y+yy*h,4f,p)}
            text(c,"Sweep",x+10,y+h-10,9,muted); text(c,"BUY",x+w*.57,y+h*.36,9,green,true); text(c,"SELL",x+w*.76,y+h*.20,9,red,true)
        }
        private fun button(c:Canvas,x:Float,y:Float,w:Float,h:Float,label:String,col:Int){rr(c,x,y,x+w,y+h,18f,Color.rgb(12,20,29));p.color=col;p.style=Paint.Style.STROKE;p.strokeWidth=1.5f;c.drawRoundRect(x,y,x+w,y+h,18f,18f,p);text(c,label,x+w/2-p.measureText(label)/2,y+35,10,col,true)}
        private fun settings(c:Canvas,pad:Float,cw:Float){
            var y=102f; text(c,"EA SETTINGS",pad,y,22,white,true);text(c,"Liquidity Sweep v1.08 controls",pad,y+22,11,muted);y+=52
            val items=arrayOf("Swing Bars" to "15","SL Points" to "5000","TP Points" to "5000","Initial Lot" to "0.01","Recovery Multiplier" to "2.00","Max Lot" to "0.05","Max Recovery" to "2","Daily Target" to "$50","Daily Loss" to "$50")
            items.forEach{(a,b)->rr(c,pad,y,pad+cw,y+58,18f,card);text(c,a,pad+16,y+23,11,muted);text(c,b,pad+cw-80,y+34,14,white,true);y+=68}
            y+=8;text(c,"TELEGRAM",pad,y,11,muted,true);y+=25;rr(c,pad,y,pad+cw,y+130,20f,card);text(c,"Bot connection",pad+16,y+28,11,white,true);text(c,"● CONFIGURED",pad+16,y+52,11,green,true);text(c,"/resume   /pause   /closeall   /status",pad+16,y+78,10,muted);button(c,pad+16,y+88,120,32,"TEST BOT",blue)
        }
        private fun logs(c:Canvas,pad:Float,cw:Float){var y=105f;text(c,"SYSTEM LOGS",pad,y,22,white,true);text(c,"Latest EA / Telegram events",pad,y+22,11,muted);y+=52;val logs=arrayOf("13:10  Telegram connected","13:08  EA status RUNNING","13:05  Sweep BUY BTCUSD","12:54  Recovery state reset","12:30  Daily limits loaded","12:00  New trading day")
            logs.forEach{v->rr(c,pad,y,pad+cw,y+52,16f,card);text(c,v,pad+15,y+31,11,white);y+=61}}
        private fun alerts(c:Canvas,pad:Float,cw:Float){var y=105f;text(c,"ALERTS",pad,y,22,white,true);text(c,"Trading notifications",pad,y+22,11,muted);y+=52;alertCard(c,pad,y,cw,"BUY SWEEP","BTCUSD liquidity sweep confirmed","13:05",green);y+=92;alertCard(c,pad,y,cw,"RECOVERY","Recovery level 0 / 2","12:54",blue);y+=92;alertCard(c,pad,y,cw,"DAILY P/L","+$12.84 today","12:30",green)}
        private fun alertCard(c:Canvas,pad:Float,y:Float,cw:Float,a:String,b:String,t:String,col:Int){rr(c,pad,y,pad+cw,y+76,18f,card);p.color=col;p.style=Paint.Style.FILL;c.drawCircle(pad+18,y+22,5f,p);text(c,a,pad+32,y+26,11,col,true);text(c,b,pad+16,y+51,11,white);text(c,t,pad+cw-50,y+26,10,muted)}
        private fun bottom(c:Canvas,w:Float){val h=height.toFloat();rr(c,0,h-76,w,h,0f,Color.rgb(8,13,20));val labels=arrayOf("HOME","SETTINGS","LOGS","ALERTS");val icons=arrayOf("⌂","⚙","≡","!");for(i in 0..3){val x=w*(i+.5f)/4f;val col=if(i==tab)green else muted;text(c,icons[i],x-7,h-45,18,col,true);text(c,labels[i],x-p.measureText(labels[i])/2,h-20,9,col,true)}}
        override fun onTouchEvent(e:android.view.MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{downY=e.y;return true};MotionEvent.ACTION_UP->{val dy=e.y-downY;if(kotlin.math.abs(dy)>50){scroll=(scroll-dy).coerceIn(0f,380f);invalidate();return true};if(e.y>height-90){tab=min(3,(e.x/(width/4f)).toInt());scroll=0f;invalidate();return true};if(tab==0 && e.y in 480f..650f && e.x>width-120){paused=!paused;Toast.makeText(this@MainActivity,if(paused)"Dashboard paused" else "Dashboard running",Toast.LENGTH_SHORT).show();invalidate();return true};return true};};return true}
    }
}
